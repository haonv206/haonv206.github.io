package vinnet.sim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
