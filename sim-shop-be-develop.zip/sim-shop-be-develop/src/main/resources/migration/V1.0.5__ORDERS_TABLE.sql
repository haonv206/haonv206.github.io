CREATE TABLE IF NOT EXISTS ORDERS (
    ID                      SERIAL          NOT NULL    PRIMARY KEY,
    CODE                    VARCHAR(50)     NULL,
    TRANSPORT_PIRCE         BIGINT          NULL,
    TOTAL_PRICE             BIGINT          NULL,
    PAYMENT_METHOD_ID       BIGINT          NULL,
    STATUS                  TEXT            NULL,
    SESSION_ID              VARCHAR(100)    NULL,
    origin_url              text            NULL,
    EXPIRE_TIME             TIMESTAMP       NULL,
    CUSTOMER_ID             BIGINT          NULL,
    CREATED_AT              TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    UPDATED_AT              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT FK_ORDER_PAYMENT_METHOD    FOREIGN KEY (PAYMENT_METHOD_ID)   REFERENCES PAYMENT_METHOD (ID),
    CONSTRAINT FK_ORDER_CUSTOMER          FOREIGN KEY (CUSTOMER_ID)         REFERENCES CUSTOMER (ID)
    );