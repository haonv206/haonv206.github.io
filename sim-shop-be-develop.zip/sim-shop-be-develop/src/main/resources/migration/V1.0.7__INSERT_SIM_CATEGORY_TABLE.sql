INSERT INTO sim_category (ID, NAME, CODE) values (1, 'Sim lộc phát', 'LP');
INSERT INTO sim_category (ID, NAME, CODE) values (2, 'Sim ngũ quý giữa', 'NQG');
INSERT INTO sim_category (ID, NAME, CODE) values (3, 'Sim ông địa', 'OD');
INSERT INTO sim_category (ID, NAME, CODE) values (4, 'Sim đảo ba', 'DB');
INSERT INTO sim_category (ID, NAME, CODE) values (5, 'Sim đảo hai', 'DH');
INSERT INTO sim_category (ID, NAME, CODE) values (6, 'Sim tam hoa','TH' );
INSERT INTO sim_category (ID, NAME, CODE) values (7, 'Sim thần tài', 'TT');
INSERT INTO sim_category (ID, NAME, CODE) values (8, 'Sim tiến liên', 'TL');
INSERT INTO sim_category (ID, NAME, CODE) values (9, 'Sim tứ quý giữa', 'TQG');

