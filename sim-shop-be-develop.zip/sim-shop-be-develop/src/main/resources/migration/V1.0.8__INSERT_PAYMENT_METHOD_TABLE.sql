INSERT INTO payment_method (ID, NAME, CODE) values (1, 'Thanh toán khi nhận hàng', 'COD');
INSERT INTO payment_method (ID, NAME, CODE) values (2, 'Cổng thanh toán trực tuyến', 'QR');


