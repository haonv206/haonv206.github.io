CREATE TABLE IF NOT EXISTS CUSTOMER (
    ID                      SERIAL          NOT NULL    PRIMARY KEY,
    NAME                    TEXT            NULL,
    PHONE                   VARCHAR(15)     NULL,
    EMAIL                   VARCHAR(50)     NULL,
    PROVINCE                VARCHAR(150)    NULL,
    DISTRICT                VARCHAR(150)    NULL,
    VILLAGE                 VARCHAR(100)    NULL,
    ADDRESS                 TEXT            NULL,
    NOTE                    TEXT            NULL,
    PAYMENT_METHOD_ID       BIGINT          NULL,
    CREATED_AT              TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    UPDATED_AT              TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
    );