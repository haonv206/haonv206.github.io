package vinnet.sim.domain.request;

import lombok.Data;

@Data
public class CustomerReq {
    private String name;
    private String phone;
    private String email;
    private String province;
    private String district;
    private String village;
    private String address;
    private String note;
}
