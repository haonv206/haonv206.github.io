package vinnet.sim.domain.request;

import lombok.Data;

import java.util.List;

@Data
public class GetSimReq {
  private String phoneNumber;
  private Long categoryId;
  private List<Integer> exceptNumbers;
  private Integer pageSize;
  private Integer pageNumber;
}
