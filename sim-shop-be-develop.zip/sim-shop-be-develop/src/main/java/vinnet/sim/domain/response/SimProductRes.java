package vinnet.sim.domain.response;

import lombok.Builder;
import lombok.Data;
import vinnet.sim.model.SimCategory;
import vinnet.sim.model.SimProduct;

import java.util.Set;

@Data
@Builder
public class SimProductRes {
    private Long id;
    private String number;
    private String seri;
    private Double price;
    private Boolean isLocked;
    private Boolean isPrepaid;
//    private LocalDateTime createAt;
//    private LocalDateTime updateAt;
    private Set<SimCategory> simCategories;

    public static SimProductRes createSimRes(SimProduct sim) {
        SimProductRes res = SimProductRes.builder()
                .id(sim.getId())
                .number(sim.getNumber())
                .seri(sim.getSeri())
                .price(sim.getPrice())
                .isLocked(sim.getIsLocked())
                .isPrepaid(sim.getIsPrepaid())
                .simCategories(sim.getSimCategories())
                .build();
        return res;
    }
}
