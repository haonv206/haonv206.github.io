package vinnet.sim.domain.response;

import lombok.Data;
import vinnet.sim.model.Order;

@Data
public class PaymentConfirmRes {
  private String paymentMethodCode;
  private String url;
  private Order order;
}
