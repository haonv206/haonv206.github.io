package vinnet.sim.domain.request;

import lombok.Data;

@Data
public class LockSimReq {
  private String status;
  private String number;
  private String sessionId;
}
