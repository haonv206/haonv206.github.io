package vinnet.sim.domain.request;

import lombok.Data;

@Data
public class CreatCartReq {
//    private List<ProductRes> productRes;
    private CustomerReq customer;
    private String originUrl;
    private Long paymentMethodId;
    private String sessionId;
}
