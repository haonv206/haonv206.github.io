package vinnet.sim.domain.response;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class DataListRes<T> {
  private List<T> data;
}
