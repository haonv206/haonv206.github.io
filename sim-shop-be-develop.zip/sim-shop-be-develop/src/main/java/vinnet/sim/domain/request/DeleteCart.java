package vinnet.sim.domain.request;

import lombok.Data;

@Data
public class DeleteCart {
  private String sessionId;
}
