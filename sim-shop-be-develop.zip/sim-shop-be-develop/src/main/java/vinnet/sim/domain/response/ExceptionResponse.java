package vinnet.sim.domain.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import vinnet.sim.exceptions.BaseException;

@Data
@AllArgsConstructor
public class ExceptionResponse {
    private String message;

    public static Object createFrom(BaseException exception) {
        return new ExceptionResponse(exception.getMessage());
    }

    public static Object createFrom(Exception exception) {
        return new ExceptionResponse(exception.getMessage());
    }

    public static Object createFromRes(String message) {
        return new ExceptionResponse(message);
    }

}
