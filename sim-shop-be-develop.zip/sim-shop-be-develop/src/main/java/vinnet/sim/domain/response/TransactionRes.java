package vinnet.sim.domain.response;

import lombok.Builder;
import lombok.Data;
import vinnet.sim.helper.Helper;
import vinnet.sim.model.Transaction;

import java.time.LocalDateTime;

@Data
@Builder
public class TransactionRes {
  private Long id;
  private OrderRes order;
//  private String vnpTmnCode;
  private Long amount;
//  private String vnpBankCode;
//  private String vnpBankTranNo;
  private String vnpCardType;
//  private String vnpPayDate;
  private String vnpOrderInfo;
//  private String vnpTransactionNo;
  private String vnpResponseCode;
  private String vnpTransactionStatus;
  private String description;
  private String vnpTxnRef;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;

  public static TransactionRes createTransactionRes(Transaction transaction) {
    return TransactionRes.builder()
            .id(transaction.getId())
            .order(OrderRes.createOrderRes(transaction.getOrder()))
            .amount(transaction.getVnpAmount().longValue())
//            .vnpTmnCode(transaction.getVnpTmnCode())
//            .vnpBankCode(transaction.getVnpBankCode())
//            .vnpBankTranNo(transaction.getVnpTransactionNo())
            .vnpCardType(transaction.getVnpCardType())
//            .vnpPayDate(transaction.getVnpPayDate())
            .vnpOrderInfo(transaction.getVnpOrderInfo())
//            .vnpTransactionNo(transaction.getVnpTransactionNo())
            .vnpResponseCode(transaction.getVnpResponseCode())
            .vnpTransactionStatus(transaction.getVnpTransactionStatus())
            .description(Helper.getDescription(transaction.getVnpTransactionStatus()))
            .vnpTxnRef(transaction.getVnpTxnRef())
            .createdAt(transaction.getCreatedAt())
            .updatedAt(transaction.getUpdatedAt())
            .build();
  }
}
