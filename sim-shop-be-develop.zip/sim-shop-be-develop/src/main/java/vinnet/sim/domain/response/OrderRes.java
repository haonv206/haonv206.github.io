package vinnet.sim.domain.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import vinnet.sim.model.Customer;
import vinnet.sim.model.Order;
import vinnet.sim.model.PaymentMethod;
import vinnet.sim.model.SimProduct;

import javax.persistence.Query;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
public class OrderRes {
  private Long id;
  private String code;
  private Double transportPrice;
  private Double totalPrice;
  private String status;
  private String sessionId;
  private LocalDateTime expireTime;
  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private PaymentMethod paymentMethod;
  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Customer customer;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;
  private String originUrl;
  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Set<SimProduct> simProducts;

  public static OrderRes createOrderRes(Order order){
    OrderRes res = OrderRes.builder()
            .id(order.getId())
            .code(order.getCode())
            .transportPrice(order.getTransportPrice())
            .totalPrice(order.getTotalPrice())
            .status(order.getStatus())
            .sessionId(order.getSessionId())
            .expireTime(order.getExpireTime())
            .paymentMethod(order.getPaymentMethod())
            .customer(order.getCustomer())
            .createdAt(order.getCreatedAt())
            .updatedAt(order.getUpdatedAt())
            .originUrl(order.getOriginUrl())
            .simProducts(order.getSimProducts())
            .build();

    return res;

  }
}
