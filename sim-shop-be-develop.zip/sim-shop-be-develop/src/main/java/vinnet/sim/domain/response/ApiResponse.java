package vinnet.sim.domain.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;
import vinnet.sim.enums.DomainCode;

@Data
@With
@JsonInclude(JsonInclude. Include.NON_NULL)
@NoArgsConstructor
public class ApiResponse {
  private Object data;
  private String code =  DomainCode.SUCCESS.getCode();
  private String message;

  public  ApiResponse(Object data, String code, String message) {
    this.data = data;
    this.code = code;
    this.message = message;
  }

}
