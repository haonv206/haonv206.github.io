package vinnet.sim.domain.request;

import lombok.Data;

@Data
public class StatusTransactionReq {
  private Long orderId;
  private String sessionId;
}
