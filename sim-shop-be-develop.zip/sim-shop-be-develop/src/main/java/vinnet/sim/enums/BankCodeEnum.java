package vinnet.sim.enums;

public enum BankCodeEnum {
  VNPAYQR,//Thanh toan quet QR
  VNBANK, //Thẻ ATM - Tài khoản ngân hàng nội địa
  INTCARD //Thẻ thanh toán quốc tế
}
