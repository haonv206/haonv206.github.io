package vinnet.sim.service;

import org.springframework.stereotype.Service;
import vinnet.sim.domain.request.StatusTransactionReq;
import vinnet.sim.domain.response.TransactionRes;
import vinnet.sim.model.Transaction;

@Service
public class TransactionService extends BaseService {


  public Object checkStatusTransaction(StatusTransactionReq req) {

    Transaction transaction = transactionRepository.findByOrderId(req.getOrderId());
    return TransactionRes.createTransactionRes(transaction);

  }

}
