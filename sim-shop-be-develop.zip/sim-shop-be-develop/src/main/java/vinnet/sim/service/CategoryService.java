package vinnet.sim.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vinnet.sim.domain.response.DataListRes;
import vinnet.sim.model.SimCategory;

import java.util.List;
@Service
@Slf4j
public class CategoryService extends BaseService{
  public Object getCategories() {
    List<SimCategory> categories = simCategoryRepository.findAll();
    return new DataListRes<>(categories);
  }
}
