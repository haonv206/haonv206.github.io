package vinnet.sim.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import vinnet.sim.base.CustomPage;
import vinnet.sim.domain.request.GetSimReq;
import vinnet.sim.domain.response.DataRes;
import vinnet.sim.domain.response.SimProductRes;
import vinnet.sim.exceptions.BadRequestException;
import vinnet.sim.helper.Constant;
import vinnet.sim.helper.Helper;
import vinnet.sim.model.SimCategory;
import vinnet.sim.model.SimProduct;

import javax.persistence.Query;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SimService extends BaseService {

  public DataRes importSim(MultipartFile excelFile) {
    if (excelFile == null) throw new BadRequestException(Constant.ERROR_CODE.EXCEL_NULL);

    List<SimProduct> simProducts;
    List<SimProductRes> simProductRes = new ArrayList<>();
    Map<String, SimCategory> mapSimCategory =
            simCategoryRepository.findAll().stream()
                    .collect(Collectors.toMap(SimCategory::getCode, Function.identity()));

    List<SimProduct> simProductAll = simProductRepository.findAll();

    try {
      if (Helper.hasExcelFormat(excelFile)) {
        //import file excel chua sanh sach so dien thoai vao db
        simProducts = Helper.readExcelToPhoneNumber(excelFile, mapSimCategory);

        if (CollectionUtils.isNotEmpty(simProducts) && (CollectionUtils.isNotEmpty(simProductAll))) {
            Map<String, SimProduct> mapSimProductAll = simProductAll.stream()
                    .collect(Collectors.toMap(SimProduct::getNumber, Function.identity()));


            Iterator<SimProduct> iterator = simProducts.iterator();

            while (iterator.hasNext()) {
              SimProduct simProduct = iterator.next();

              if (mapSimProductAll.containsKey(simProduct.getNumber())) {
                iterator.remove();
              }
            }

        }
        if (simProducts != null && CollectionUtils.isNotEmpty(simProducts)) {
          simProductRepository.saveAll(simProducts);

          for (SimProduct simProduct : simProducts) {
            simProductRes.add(
                    SimProductRes.builder()
                            .id(simProduct.getId())
                            .number(simProduct.getNumber())
                            .price(simProduct.getPrice())
                            .seri(simProduct.getSeri())
                            .isPrepaid(simProduct.getIsPrepaid())
                            .simCategories(simProduct.getSimCategories())
                            .build()
            );
          }
        }
      }
    } catch (BadRequestException badRequestException) {
      throw new BadRequestException(Constant.ERROR_CODE.CELL_TYPE_EXCEL_WAS_WRONG);
    }

    return new DataRes(simProductRes);
  }


  public Object getAll(GetSimReq req) {
    Pageable pageable;
    if (req.getPageSize() != null && req.getPhoneNumber() != null) {
      pageable = PageRequest.of(req.getPageNumber(), req.getPageSize());
    } else {
      pageable = PageRequest.of(0, 20);
    }

    Page<SimProduct> simProducts = getAllSimByCondition(req.getPhoneNumber(), req.getCategoryId(),
            req.getExceptNumbers(), pageable);

    if (simProducts.getContent().isEmpty()) return new CustomPage<>(simProducts);

    List<SimProductRes> simRes = new ArrayList<>();
    for (SimProduct sim : simProducts.getContent()){
      simRes.add(SimProductRes.createSimRes(sim));
    }

    Page<SimProductRes> page = Helper.convertToPage(pageable, simRes, simProducts.getTotalElements());
    //Convert to res
    return new CustomPage<>(page);

  }

  private Page<SimProduct> getAllSimByCondition(String phoneNumber, Long categoryId, List<Integer> exceptNumbers, Pageable pageable) {
    Map<String, Object> params = new HashMap<>();
    Map<String, Object> paramsCount = new HashMap<>();
    StringBuilder sql = new StringBuilder();
    StringBuilder sqlCount = new StringBuilder();

    sql.append("SELECT s.* FROM sim_product s " +
            "LEFT JOIN sim_product_category sc ON sc.sim_product_id = s.ID " +
            " WHERE s.IS_LOCKED = false ");

    sqlCount.append("SELECT COUNT(s.*) FROM sim_product s " +
            "LEFT JOIN sim_product_category sc ON sc.sim_product_id = s.ID " +
            " WHERE s.IS_LOCKED = false ");
    if (phoneNumber != null && !phoneNumber.isEmpty()) {

      // Truong hop co dau "*" VD: "*23, 90*, *8*8*
      if (phoneNumber.contains("*")) {
        StringBuilder stringBuilder = new StringBuilder(" AND s.number LIKE '");
        stringBuilder.append(phoneNumber.replace("*", "%"));
        stringBuilder.append("%' ");

        sql.append(stringBuilder);
        sqlCount.append(stringBuilder);
      } else {
        sql.append("AND s.number LIKE CONCAT('%', :phoneNumber, '%') ");
        sqlCount.append("AND s.number LIKE CONCAT('%', :phoneNumber, '%') ");
        params.put("phoneNumber", phoneNumber);
        paramsCount.put("phoneNumber", phoneNumber);
      }

    }

    if (exceptNumbers != null && !exceptNumbers.isEmpty()) {
      StringBuilder stringBuilder = new StringBuilder();
      for (Integer i = 0; i < exceptNumbers.size(); i++) {
        if (exceptNumbers.get(i) == 0) {
          stringBuilder.append(" AND SUBSTRING(s.number, 2, 10) NOT LIKE '%0%' ");
        } else {
          stringBuilder.append(" AND s.number NOT LIKE '%");
          stringBuilder.append(exceptNumbers.get(i));
          stringBuilder.append("%' ");
        }

      }
      sql.append(stringBuilder);
      sqlCount.append(stringBuilder);
    }

    if (categoryId != null) {
      sql.append("AND sc.sim_category_id = :categoryId ");
      sqlCount.append("AND sc.sim_category_id = :categoryId ");
      params.put("categoryId", categoryId);
      paramsCount.put("categoryId", categoryId);
    }

    int pageSize = pageable.getPageSize();
    int offset = pageable.getPageNumber() * pageable.getPageSize();
    sql.append(" GROUP BY s.ID ORDER BY s.ID DESC limit :pageSize offset :offset ");
    sqlCount.append(" GROUP BY s.ID ");
    params.put("pageSize", pageSize);
    params.put("offset", offset);

    Query query = entityManager.createNativeQuery(sql.toString(), SimProduct.class);
    Query queryCount = entityManager.createNativeQuery(sqlCount.toString());
    for (Map.Entry<String, Object> param : params.entrySet()) {
      query.setParameter(param.getKey(), param.getValue());
    }

    for (Map.Entry<String, Object> param : paramsCount.entrySet()) {
      queryCount.setParameter(param.getKey(), param.getValue());
    }

    List<BigInteger> resultList = queryCount.getResultList();
    return new PageImpl<>(query.getResultList(), pageable, resultList.size());

  }

}
