package vinnet.sim.service;

import org.springframework.beans.factory.annotation.Autowired;
import vinnet.sim.repository.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

@Transactional
public class BaseService {
    @Autowired SimCategoryRepository simCategoryRepository;
    @Autowired SimProductRepository simProductRepository;
    @Autowired PaymentMethodRepository paymentMethodRepository;
    @Autowired OrderRepository orderRepository;
    @Autowired CustomerRepository customerRepository;
    @Autowired ConnectionVNPayService connectionVNPayService;
    @Autowired TransactionRepository transactionRepository;
    @PersistenceContext public EntityManager entityManager;
}
