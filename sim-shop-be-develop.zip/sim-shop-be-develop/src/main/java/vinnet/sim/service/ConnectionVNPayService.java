package vinnet.sim.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import vinnet.sim.enums.Status;
import vinnet.sim.exceptions.ResourceNotFoundException;
import vinnet.sim.helper.Config;
import vinnet.sim.helper.Constant;
import vinnet.sim.helper.Helper;
import vinnet.sim.model.Order;
import vinnet.sim.model.SimProduct;
import vinnet.sim.model.Transaction;

import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Slf4j
public class ConnectionVNPayService extends BaseService {

  @Value("${vnp_secret_key}")
  public String vnp_HashSecret; //Chuỗi bí mật sử dụng để kiểm tra toàn vẹn dữ liệu khi hai hệ thống trao đổi thông tin (checksum).

  @Value("${vnp_url_payment}")
  public String vnp_PayUrl; //url cua VNPay

  @Value("${vnp_tmn_code}")
  public String vnp_TmnCode;

  @Value("${vnnet_url_callback}")
  public String vnp_Returnurl; //url callback

  public String getUrlPaymentToVNPay(HttpServletRequest req, Order order) {

    String vnp_Version = "2.1.0";
    String vnp_Command = "pay";
    String vnp_OrderInfo = "Thanh toan don hang " + order.getCode() + " so tien " + order.getTotalPrice() + " VND";  //Thong tin giao dich
    String orderType = "other";
    String vnp_TxnRef = order.getCode(); //Ma don hang
    String vnp_IpAddr = Config.getIpAddress(req); //Dia chi ip

    int amount = (int) (order.getTotalPrice() * 100);
    Map vnp_Params = new HashMap<>();
    vnp_Params.put("vnp_Version", vnp_Version);
    vnp_Params.put("vnp_Command", vnp_Command);
    vnp_Params.put("vnp_TmnCode", vnp_TmnCode);
    vnp_Params.put("vnp_Amount", String.valueOf(amount));
    vnp_Params.put("vnp_CurrCode", "VND");

    vnp_Params.put("vnp_TxnRef", vnp_TxnRef);
    vnp_Params.put("vnp_OrderInfo", vnp_OrderInfo);
    vnp_Params.put("vnp_OrderType", orderType);

    vnp_Params.put("vnp_Locale", "vn");
    vnp_Params.put("vnp_ReturnUrl", vnp_Returnurl);
    vnp_Params.put("vnp_IpAddr", vnp_IpAddr);
    Calendar cld = Calendar.getInstance(TimeZone.getTimeZone("Etc/GMT+7"));

    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    String vnp_CreateDate = formatter.format(cld.getTime());

    vnp_Params.put("vnp_CreateDate", vnp_CreateDate);
    //Build data to hash and querystring
    Map<String, String> map = createStringFromMap(vnp_Params);
    String queryUrl = map.get("query");

    String vnp_SecureHash = Config.hmacSHA512(vnp_HashSecret, map.get("hashData"));
//    log.info("getUrlPaymentToVNPay_vnp_SecureHash: " + vnp_SecureHash);
    queryUrl += "&vnp_SecureHash=" + vnp_SecureHash;

    String url = vnp_PayUrl + "?" + queryUrl;
    log.info("Payment VNP: url=" + url);
    return url;
  }

  public Map<String, String> createStringFromMap(Map<String, String> map) {
    Map<String, String> result = new HashMap<>();
    List<String> fieldNames = new ArrayList<>(map.keySet());
    Collections.sort(fieldNames);
    StringBuilder hashData = new StringBuilder();
    StringBuilder query = new StringBuilder();
    Iterator itr = fieldNames.iterator();
    while (itr.hasNext()) {
      String fieldName = (String) itr.next();
      String fieldValue = map.get(fieldName);
      if ((fieldValue != null) && (!fieldValue.isEmpty())) {
        //Build hash data
        hashData.append(fieldName);
        hashData.append('=');
        hashData.append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII));
        //Build query
        query.append(URLEncoder.encode(fieldName, StandardCharsets.US_ASCII));
        query.append('=');
        query.append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII));
        if (itr.hasNext()) {
          query.append('&');
          hashData.append('&');
        }
      }
    }
    result.put("query", query.toString());
    result.put("hashData", hashData.toString());
    return result;
  }


  public String ipnFromVNPay(HttpServletRequest request) {

    String result;
    try {
      log.info("bắt đầu chạy vào nhận phản hồi VnPay");
      /*  IPN URL: Record payment results from VNPAY
       */

      // ex:  	PaymnentStatus = 0; pending
      //              PaymnentStatus = 1; success
      //              PaymnentStatus = 2; Faile

      //Begin process return from VNPAY
      Map<String, String> fields = new HashMap<>();
      for (Enumeration params = request.getParameterNames(); params.hasMoreElements(); ) {
        String fieldName = URLDecoder.decode((String) params.nextElement(), StandardCharsets.US_ASCII);
        String fieldValue = URLDecoder.decode(request.getParameter(fieldName), StandardCharsets.US_ASCII);
        if ((fieldValue != null) && (fieldValue.length() > 0)) {
          fields.put(fieldName, fieldValue);
        }
      }

      log.info("IPN request: ClientIP=" + request.getRemoteAddr() + ",Data=" + fields);
      String vnp_SecureHash = request.getParameter("vnp_SecureHash");
      if (fields.containsKey("vnp_SecureHashType")) {
        fields.remove("vnp_SecureHashType");
      }
      if (fields.containsKey("vnp_SecureHash")) {
        fields.remove("vnp_SecureHash");
      }

      // Check checksum
      String signValue = Config.hmacSHA512(vnp_HashSecret, createStringFromMap(fields).get("hashData"));

      Transaction transaction = null;
      if (signValue.equals(vnp_SecureHash)) {

        boolean checkOrderId = true; // vnp_TxnRef exists in your database
        boolean checkAmount = true; // vnp_Amount is valid (Check vnp_Amount VNPAY returns compared to the amount of
        // the code (vnp_TxnRef) in the Your database).
        boolean checkOrderStatus = true; // PaymnentStatus = 0 (pending)

        Order order = orderRepository.findByCode(fields.get("vnp_TxnRef"));
        if (order == null) {
          checkOrderId = false;

        } else {
          transaction = transactionRepository.findByOrderId(order.getId());
          if (transaction == null) {
            transaction = new Transaction();
            transaction.setOrder(order);

          } else {
            Double newAmount = Double.valueOf(fields.get("vnp_Amount")) / 100;
            if (!transaction.getVnpAmount().equals(newAmount)) {
              checkOrderStatus = false;
              checkAmount = false;
            }
            if (transaction.getStatus().equals(Status.COMPLETED.name())) {
              checkOrderStatus = false;
            }

          }
          transaction = createTransactionForVnPay(fields, order, transaction);
        }

        if (checkOrderId) {
          if (checkAmount) {
            if (checkOrderStatus) {
              if ("00".equals(request.getParameter("vnp_ResponseCode"))) {
                //Here Code update PaymnentStatus = 1 into your Database
                order.setStatus(Status.WAITING_CONFIRMATION.name());
                orderRepository.save(order);

              } else {
                // Here Code update PaymnentStatus = 2 into your Database
                order.setStatus(Status.CANCEL.name());

                Set<SimProduct> simProducts = order.getSimProducts();
                simProducts.forEach(simProduct -> simProduct.setIsLocked(false));

                orderRepository.save(order);
                simProductRepository.saveAll(simProducts);

              }
              transactionRepository.save(transaction);
              result = "{\"RspCode\":\"00\",\"Message\":\"Confirm Success\"}";
            } else {
              result = "{\"RspCode\":\"02\",\"Message\":\"Order already confirmed\"}";
            }
          } else {
            result = "{\"RspCode\":\"04\",\"Message\":\"Invalid Amount\"}";
          }
        } else {
          result = "{\"RspCode\":\"01\",\"Message\":\"Order not Found\"}";
        }
      } else {
        result = "{\"RspCode\":\"97\",\"Message\":\"Invalid Checksum\"}";
      }

    } catch (Exception e) {
      result = "{\"RspCode\":\"99\",\"Message\":\"Unknow error\"}";
    }

    log.info("IPN response: ClientIP=" + request.getRemoteAddr() + ",Data=" + result);
    return result;
  }

  public String returnFromVNPay(HttpServletRequest request) {
    //Begin process return from VNPAY
    Map<String, String> fields = new HashMap<>();
    for (Enumeration params = request.getParameterNames(); params.hasMoreElements(); ) {
      String fieldName = URLDecoder.decode((String) params.nextElement(), StandardCharsets.US_ASCII);
      String fieldValue = URLDecoder.decode(request.getParameter(fieldName), StandardCharsets.US_ASCII);
      if ((fieldValue != null) && (!fieldValue.isEmpty())) {
        fields.put(fieldName, fieldValue);
      }
    }
    log.info("Return URL request: ClientIP=" + request.getRemoteAddr() + ",Data=" + fields);
    fields.remove("vnp_SecureHashType");
    fields.remove("vnp_SecureHash");

    Order order = orderRepository.findByCode(fields.get("vnp_TxnRef"));

    if (order == null) throw new ResourceNotFoundException(Constant.ERROR_CODE.ORDER_NOT_FOUND);
    Transaction transaction = transactionRepository.findByOrderId(order.getId());
    if (transaction == null) {
      transaction = new Transaction();
    }

    if (!order.getStatus().equals(Status.WAITING_CONFIRMATION.name())) {

      String vnp_SecureHash = request.getParameter("vnp_SecureHash");
      fields.remove("vnp_SecureHashType");
      fields.remove("vnp_SecureHash");

      Map<String, String> map = createStringFromMap(fields);

      String signValue = Config.hmacSHA512(vnp_HashSecret, map.get("hashData"));

      transaction.setOrder(order);
      Double amount = Double.valueOf(fields.get("vnp_Amount")) / 100;
      transaction.setVnpAmount(amount);
      transaction.setVnpTmnCode(fields.get("vnp_TmnCode"));
      transaction.setVnpBankCode(fields.get("vnp_BankCode"));
      transaction.setVnpBankTranNo(fields.get("vnp_BankTranNo"));
      transaction.setVnpCardType(fields.get("vnp_CardType"));
      transaction.setVnpPayDate(fields.get("vnp_PayDate"));
      transaction.setVnpOrderInfo(fields.get("vnp_OrderInfo"));
      transaction.setVnpTransactionNo(fields.get("vnp_TransactionNo"));
      transaction.setVnpResponseCode(fields.get("vnp_ResponseCode"));
      transaction.setVnpTransactionStatus(fields.get("vnp_TransactionStatus"));
      transaction.setVnpTxnRef(fields.get("vnp_TxnRef"));
      transaction.setStatus(fields.get("vnp_TransactionStatus").equals("00") ? Status.COMPLETED.name() : Status.FAILED.name());

      transactionRepository.save(transaction);

      //Cap nhat trang thai don hang o day
      if (signValue.equals(vnp_SecureHash)) {
        if ("00".equals(request.getParameter("vnp_ResponseCode"))) {
          order.setStatus(Status.WAITING_CONFIRMATION.name());
        } else {
          Set<SimProduct> simProducts = order.getSimProducts();
          simProducts.forEach(simProduct -> simProduct.setIsLocked(false));
          simProductRepository.saveAll(simProducts);

          order.setStatus(Status.CANCEL.name());
        }

      } else {
        Set<SimProduct> simProducts = order.getSimProducts();
        simProducts.forEach(simProduct -> simProduct.setIsLocked(false));
        simProductRepository.saveAll(simProducts);
        order.setStatus(Status.CANCEL.name());
      }
      transaction.setDescription(Helper.getDescription(fields.get("vnp_TransactionStatus")));
      orderRepository.save(order);
//      log.info("returnFromVNPay==== end ");

    } // Neu da xac nhan roi thi khong cap nhat gd nua
    return order.getOriginUrl();
  }

  private Transaction createTransactionForVnPay(Map<String, String> fields, Order order, Transaction transaction) {

    transaction.setOrder(order);

    if (fields.containsKey("vnp_TmnCode")) {
      transaction.setVnpTmnCode(fields.get("vnp_TmnCode"));
    }

    if (fields.containsKey("vnp_Amount")) {
      Double amount = Double.valueOf(fields.get("vnp_Amount")) / 100;
      transaction.setVnpAmount(amount);
    }

    if (fields.containsKey("vnp_BankCode")) {
      transaction.setVnpBankCode(fields.get("vnp_BankCode"));
    }

    if (fields.containsKey("vnp_BankTranNo")) {
      transaction.setVnpBankTranNo(fields.get("vnp_BankTranNo"));
    }

    if (fields.containsKey("vnp_CardType")) {
      transaction.setVnpCardType(fields.get("vnp_CardType"));
    }

    if (fields.containsKey("vnp_PayDate")) {
      transaction.setVnpPayDate(fields.get("vnp_PayDate"));
    }

    if (fields.containsKey("vnp_OrderInfo")) {
      transaction.setVnpOrderInfo(fields.get("vnp_OrderInfo"));
    }

    if (fields.containsKey("vnp_TransactionNo")) {
      transaction.setVnpTransactionNo(fields.get("vnp_TransactionNo"));
    }

    if (fields.containsKey("vnp_ResponseCode")) {
      transaction.setVnpResponseCode(fields.get("vnp_ResponseCode"));
    }

    if (fields.containsKey("vnp_TransactionStatus")) {
      transaction.setVnpTransactionStatus(fields.get("vnp_TransactionStatus"));
    }

    if (fields.containsKey("vnp_TxnRef")) {
      transaction.setVnpTxnRef(fields.get("vnp_TxnRef"));
    }

    if (fields.containsKey("vnp_SecureHashType")) {
      transaction.setVnpSecureHashType(fields.get("vnp_SecureHashType"));
    }

    if (fields.containsKey("vnp_SecureHash")) {
      transaction.setVnpSecureHash(fields.get("vnp_SecureHash"));
    }
    transaction.setStatus(fields.get("vnp_TransactionStatus").equals("00") ? Status.COMPLETED.name() : Status.FAILED.name());

    return transaction;
  }

}
