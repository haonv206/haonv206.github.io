package vinnet.sim.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import vinnet.sim.domain.request.CreatCartReq;
import vinnet.sim.domain.request.LockSimReq;
import vinnet.sim.domain.response.DataRes;
import vinnet.sim.domain.response.PaymentConfirmRes;
import vinnet.sim.enums.Status;
import vinnet.sim.exceptions.BadRequestException;
import vinnet.sim.exceptions.ResourceNotFoundException;
import vinnet.sim.helper.Constant;
import vinnet.sim.helper.Helper;
import vinnet.sim.model.Customer;
import vinnet.sim.model.SimProduct;
import vinnet.sim.model.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.*;

@Service
@Slf4j
public class OrderService extends BaseService {

  @Value("${server.servlet.context-path}")
  private String contextPath;
  public Object paymentConfirm(CreatCartReq orderReq, HttpServletRequest req) {

    Helper.checkTheInputData(orderReq);

    Order order = orderRepository.findBySessionIdAndStatus(orderReq.getSessionId(), Status.NEW.name());
    if (order == null) throw new ResourceNotFoundException(Constant.ERROR_CODE.PHONE_IS_LOCKED);

    Customer customer = new Customer();
    customer.setName(orderReq.getCustomer().getName());
    customer.setPhone(orderReq.getCustomer().getPhone());
    customer.setEmail(orderReq.getCustomer().getEmail() != null ? orderReq.getCustomer().getEmail() : null);
    customer.setProvince(orderReq.getCustomer().getProvince());
    customer.setDistrict(orderReq.getCustomer().getDistrict());
    customer.setVillage(orderReq.getCustomer().getVillage());
    customer.setAddress(orderReq.getCustomer().getAddress());
    customer.setNote(orderReq.getCustomer().getNote() != null ? orderReq.getCustomer().getNote() : null);
    customerRepository.save(customer);

    order.setCustomer(customer);
    PaymentMethod paymentMethod = paymentMethodRepository.getById(orderReq.getPaymentMethodId());
    if (paymentMethod == null) throw new ResourceNotFoundException(Constant.ERROR_CODE.PAYMENT_METHOD_NOT_FOUND);
    order.setPaymentMethod(paymentMethod); // 1: COD, 2: QR
    order.setOriginUrl(orderReq.getOriginUrl());

    PaymentConfirmRes res = new PaymentConfirmRes();
    switch (paymentMethod.getCode()) {
      case "COD":
        res.setPaymentMethodCode("COD");
        order.setStatus(Status.WAITING_CONFIRMATION.name());
        res.setUrl(orderReq.getOriginUrl());
        break;
      case "QR": //Phuong thuc thanh toan truc tuyen
        res.setPaymentMethodCode("QR");
        order.setExpireTime(LocalDateTime.now().plusMinutes(20));
        res.setUrl(connectionVNPayService.getUrlPaymentToVNPay(req, order));
        break;
      default:
        break;
    }

    order = orderRepository.save(order);
    res.setOrder(order);
    return res;
  }

  public Object changeStatusSim(LockSimReq req, HttpSession session) {

    checkParamChangeStatusSim(req);

    Order orderRes = new Order();
    Order orderDtoOld;

    switch (req.getStatus()) {
      case Constant.SIM_TYPE.ACTIVE:
        if (req.getSessionId() == null || req.getSessionId().isBlank()){
          throw new BadRequestException(Constant.ERROR_CODE.SESSION_NULL);
        }
        orderDtoOld =  orderRepository.findBySessionIdAndStatus(req.getSessionId(), Status.NEW.name());
        if (orderDtoOld == null) throw new BadRequestException(Constant.ERROR_CODE.ORDER_NULL);
        boolean checkNumber = orderDtoOld.getSimProducts().stream().anyMatch(simProduct -> simProduct.getNumber().equals(req.getNumber()));
        if (!checkNumber) throw new BadRequestException(Constant.ERROR_CODE.SIM_NOT_FOUND);
        SimProduct number = orderDtoOld.getSimProducts().stream()
                .filter(simProduct -> simProduct.getNumber().equals(req.getNumber()))
                .findFirst()
                .orElse(null);
        orderDtoOld.getSimProducts().remove(number);
        if (orderDtoOld.getSimProducts().isEmpty()){
          orderRepository.delete(orderDtoOld);
        }else {
          orderDtoOld.setTotalPrice(orderDtoOld.getTotalPrice() - (number == null ? 0 : number.getPrice()));

          orderRepository.save(orderDtoOld);
        }

        if (number != null){
          number.setIsLocked(false);
          simProductRepository.save(number);
        }

        break;
      case Constant.SIM_TYPE.INACTIVE:
        List<String> status = Arrays.asList(Status.NEW.name());
        SimProduct sim = simProductRepository.findByNumberAndIsLocked(req.getNumber(), Boolean.FALSE);
        if (sim == null) throw new ResourceNotFoundException(Constant.ERROR_CODE.SIM_NOT_FOUND);

        if (req.getSessionId() != null && !req.getSessionId().isEmpty()) {

          orderDtoOld = orderRepository.findBySessionIdAndStatusIn(req.getSessionId(), status);
        }else {
          orderDtoOld =  orderRepository.findBySessionIdAndStatusIn(session.getId(), status);
        }

        if (orderDtoOld != null) {
            Set<SimProduct> simProductSet = orderDtoOld.getSimProducts();
            if(simProductSet.size() > 5){
              throw new ResourceNotFoundException(Constant.ERROR_CODE.ORDER_MAX_PHONE);
            }

            simProductSet.add(sim);

            orderDtoOld.setSimProducts(simProductSet);
            orderDtoOld.setTotalPrice(orderDtoOld.getTotalPrice() + sim.getPrice());

            orderRepository.save(orderDtoOld);
            orderRes = orderDtoOld;
        } else {
          Order orderDtoNew = new Order();
          orderDtoNew.setTransportPrice(30000D);
          orderDtoNew.setTotalPrice(sim.getPrice() + 30000D);

          Set<SimProduct> simProductSet = new HashSet<>();
          simProductSet.add(sim);

          orderDtoNew.setSessionId(req.getSessionId() != null && !req.getSessionId().isEmpty() ? req.getSessionId() :session.getId());
          orderDtoNew.setSimProducts(simProductSet);
          orderDtoNew.setExpireTime(LocalDateTime.now().plusMinutes(20));
          orderDtoNew.setStatus(Status.NEW.name());
          //Tao mot ma don hang theo dinh dang

          orderDtoNew = orderRepository.save(orderDtoNew);
          orderDtoNew.setCode(Helper.createOrderCode(orderDtoNew.getId()));
          orderRepository.save(orderDtoNew);
          orderRes = orderDtoNew;

        }

        sim.setIsLocked(true);
        simProductRepository.save(sim);
        break;
      default:
        throw new BadRequestException(Constant.ERROR_CODE.STATUS_INVALID);
    }

    return new DataRes(orderRes);
  }

  public void checkParamChangeStatusSim(LockSimReq req){
    if (req.getNumber() == null) throw new BadRequestException(Constant.ERROR_CODE.NUMBER_NULL);
  }

}
