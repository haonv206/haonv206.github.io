package vinnet.sim.schedule;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import vinnet.sim.enums.Status;
import vinnet.sim.model.Order;
import vinnet.sim.model.SimProduct;
import vinnet.sim.repository.OrderRepository;
import vinnet.sim.repository.SimProductRepository;

import javax.transaction.Transactional;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
@Transactional
public class SimSchedule {
  @Autowired
  OrderRepository orderRepository;
  @Autowired
  SimProductRepository simProductRepository;

  @Scheduled(fixedRate = 2000)
  @Transactional
  public void processExpireTimeInOrder() {
    //Tim kiem theo don hang status =[NEW, CONFIRM]
    List<String> status = List.of(Status.NEW.name());

    List<Order> orders;
    LocalDateTime currentTime = LocalDateTime.now(Clock.systemUTC());
    orders = orderRepository.findAllByStatusInAndExpireTimeBefore(status, currentTime);

    if (CollectionUtils.isNotEmpty(orders)) {
      List<Long> simProductIds = new ArrayList<>();

      for (Order order : orders) {
        simProductIds.addAll(order.getSimProducts().stream().map(SimProduct::getId).collect(Collectors.toList()));
        order.setStatus(Status.CANCEL.name());
      }

      List<SimProduct> simProducts = simProductRepository.findAllById(simProductIds);

      simProducts.forEach(simProduct -> simProduct.setIsLocked(false));

      simProductRepository.saveAll(simProducts);
      orderRepository.saveAll(orders);
    }

  }

}
