package vinnet.sim.helper;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import vinnet.sim.domain.request.CreatCartReq;
import vinnet.sim.enums.VnpTransactionStatus;
import vinnet.sim.exceptions.BadRequestException;
import vinnet.sim.model.SimCategory;
import vinnet.sim.model.SimProduct;

import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
@Component
public class Helper {

  public static int POST_CODE = 100000;

  protected static final List<String> EXCEL_TYPE = Arrays.asList("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/wps-office.xls", "application/wps-office.xlsx");

  public static boolean hasExcelFormat(MultipartFile file) {
    return EXCEL_TYPE.contains(file.getContentType());
  }

  public static List<SimProduct> readExcelToPhoneNumber(MultipartFile file, Map<String, SimCategory> mapSimCategory) {
    try {
      String[] types = {"application/vnd.ms-excel", "application/wps-office.xls", "application/xls"};
      Workbook workbook = Arrays.asList(types).contains(file.getContentType()) ?
              new HSSFWorkbook(file.getInputStream()) : new XSSFWorkbook(file.getInputStream());
      Sheet sheet = workbook.getSheetAt(0);

      Map<String, SimProduct> simProductMap = new LinkedHashMap<>();

      int totalRow = sheet.getLastRowNum();

      DataFormatter dataFormatter = new DataFormatter();

      for (int i = 1; i <= totalRow; i++) {
        Row currentRow = sheet.getRow(i);
        if (currentRow == null || isRowEmpty(currentRow)) continue;

        SimProduct simProduct = new SimProduct();
        Set<SimCategory> setCategories;
        // Đọc giá trị từ cột "số thuê bao", "giá tiền", "số seri sim", và "loại sim"
        if (currentRow.getCell(0) != null && currentRow.getCell(1) != null) {
          String phone = dataFormatter.formatCellValue(currentRow.getCell(0));
          if (!Helper.validationPhone(phone)) {
            continue;
          }

          simProduct.setNumber(startsWithZero(phone) ? phone : "0" + phone);

          simProduct.setPrice(currentRow.getCell(1).getNumericCellValue());
          simProduct.setSeri(currentRow.getCell(2) != null ? currentRow.getCell(2).toString() : null);
          simProduct.setIsLocked(false);
          simProduct.setIsPrepaid(true);
        } else {
          continue;
        }

        // kiểm tra loại sim
        setCategories = checkSimCategories(simProduct.getNumber(), mapSimCategory);
        simProduct.setSimCategories(setCategories);

        simProductMap.put(simProduct.getNumber(), simProduct);
      }


      workbook.close();
      return new ArrayList<>(simProductMap.values());
    } catch (IOException e) {
      e.printStackTrace();  // Thay thế bằng xử lý ngoại lệ thích hợp
      throw new BadRequestException(Constant.ERROR_CODE.CELL_TYPE_EXCEL_WAS_WRONG);
    } catch (IllegalStateException i) {
      throw new BadRequestException(Constant.ERROR_CODE.CELL_TYPE_EXCEL_WAS_WRONG);
    }
  }

  private static boolean isRowEmpty(Row row) {
    for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
      Cell cell = row.getCell(c);
      if (cell != null && cell.getCellType() != CellType.BLANK) {
        return false;
      }
    }
    return true;
  }


  private static Set<SimCategory> checkSimCategories(String number, Map<String, SimCategory> mapSimCategory) {
    Set<SimCategory> setCategories = new HashSet<>();

    if (simLocPhat(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.LP));
    if (simOngDia(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.OD));
    if (simThanTai(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.TT));
    if (simDaoHai(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.DH));
    if (simDaoBa(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.DB));
    if (simTuQuyGiua(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.TQG));
    if (simNguQuyGiua(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.NQG));
    if (simTienLen(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.TL));
    if (simTamHoa(number)) setCategories.add(mapSimCategory.get(Constant.SIM_TYPE.TH));

    return setCategories;
  }

  private static String convertToPhoneNumber(double numericValue) {
    return String.format("%.0f", numericValue);
  }

  public static boolean simLocPhat(String phone) {
    String regex = "^\\d+(?:68|86)$";
    return phone.matches(regex);
  }

  public static boolean simOngDia(String phone) {
    String regex = "^\\d+(?:38|78)$";
    return phone.matches(regex);
  }

  public static boolean simThanTai(String phone) {
    String regex = "^\\d+(?:39|79)$";
    return phone.matches(regex);
  }

  public static boolean simDaoHai(String phone) {
    // Vi du "0770578639" => false
    String reversePhone = new StringBuilder(phone).reverse().toString();
    return reversePhone.charAt(0) == reversePhone.charAt(3)
            && reversePhone.charAt(1) == reversePhone.charAt(2);
  }

  public static boolean simDaoBa(String phone) {

    String reversePhone = new StringBuilder(phone).reverse().toString();
    return reversePhone.charAt(0) == reversePhone.charAt(5)
            && reversePhone.charAt(1) == reversePhone.charAt(4)
            && reversePhone.charAt(2) == reversePhone.charAt(3);

  }

  public static boolean simTuQuyGiua(String phone) {
    for (int i = 1; i < phone.length() - 3; i++) {
      if (phone.charAt(i) == phone.charAt(i + 1)
              && phone.charAt(i) == phone.charAt(i + 2)
              && phone.charAt(i) == phone.charAt(i + 3)) return true;
    }
    return false;
  }

  public static boolean simNguQuyGiua(String phone) {
    for (int i = 1; i < phone.length() - 4; i++) {
      if (phone.charAt(i) == phone.charAt(i + 1)
              && phone.charAt(i) == phone.charAt(i + 2)
              && phone.charAt(i) == phone.charAt(i + 3)
              && phone.charAt(i) == phone.charAt(i + 4)
      )
        return true;
    }
    return false;
  }

  public static boolean simTienLen(String phone) {
    //Kiem tra 3 so cuoi la so tien len
    //Dao chuoi
    Boolean response = false;
    String reversePhone = new StringBuilder(phone).reverse().toString();
    char[] chars = reversePhone.toCharArray();
    int[] elements = usingStreamApiMethod(chars);
    if (elements[0] >= 2 && elements[0] - 1 == elements[1]
            && elements[1] - 1 == elements[2]) response = true;

    return response;

  }

  static int[] usingStreamApiMethod(char[] chars) {

    return new String(chars).chars()
            .map(c -> c - 48)
            .toArray();
  }

  public static boolean simTamHoaGiua(String phone) {
    String pattern = "(.).*(\\1){2}";
    Pattern p = Pattern.compile(pattern);
    Matcher m = p.matcher(phone);
    return m.find();
  }

  public static boolean simTamHoa(String input) {
    String pattern = "(\\d)\\1{2}";
    Pattern p = Pattern.compile(pattern);
    Matcher m = p.matcher(input);
    return m.find();
  }


  public static boolean validationName(String name) {
    return name.matches("^[a-zA-Z0-9 ]{1,30}$");
  }

  public static boolean validationAddress(String name) {
    return name.matches("^[a-zA-Z0-9 ]{1,100}$");
  }

  public static boolean validationPhone(String number) {
    if (!startsWithZero(number)) {
      number = "0" + number;
    }
    return number.matches("^(0|\\+84)(\\s|\\.)?((3[2-9])|(5[689])|(7[06-9])|(8[1-689])|(9[0-46-9]))(\\d)(\\s|\\.)?(\\d{3})(\\s|\\.)?(\\d{3})$");
  }

  public static boolean startsWithZero(String str) {
    return str.startsWith("0");
  }

  public static boolean validationEmail(String number) {
    return number.matches("^(.+)@(\\S+)$");
  }

  public static void checkTheInputData(CreatCartReq creatCartReq) {
    if (creatCartReq.getCustomer().getDistrict() == null || creatCartReq.getCustomer().getDistrict().isBlank())
      throw new BadRequestException(Constant.ERROR_CODE.DISTRICT_NULL);

    if (creatCartReq.getCustomer().getProvince() == null || creatCartReq.getCustomer().getProvince().isBlank())
      throw new BadRequestException(Constant.ERROR_CODE.PROVINCE_NULL);

    if (creatCartReq.getCustomer().getVillage() == null || creatCartReq.getCustomer().getVillage().isBlank())
      throw new BadRequestException(Constant.ERROR_CODE.VILLAGE_NULL);

    if (creatCartReq.getCustomer().getName().length() > 30 || creatCartReq.getCustomer().getName().isBlank())
      throw new BadRequestException(Constant.ERROR_CODE.INVALID_NAME);

    if (!Helper.validationPhone(creatCartReq.getCustomer().getPhone()))
      throw new BadRequestException(Constant.ERROR_CODE.INVALID_PHONE);

//    if (creatCartReq.getCustomer().getEmail() != null && !Helper.validationEmail(creatCartReq.getCustomer().getEmail()))
//      throw new BadRequestException(Constant.ERROR_CODE.INVALID_EMAIL);

    if (creatCartReq.getCustomer().getAddress().length() > 100)
      throw new BadRequestException(Constant.ERROR_CODE.INVALID_ADDRESS);

  }

  public static String createOrderCode( Long id) {
    String result = "VINNET" + POST_CODE + id;
    return result;
  }

  public static <T> Page<T> convertToPage(Pageable pageable, List<T> objectList, long total) {
    int start = 0;
    int end = (start + pageable.getPageSize()) > objectList.size() ? objectList.size()
            : (start + pageable.getPageSize());
    return new PageImpl<>(objectList.subList(start, end), pageable, total);
  }

  public static String getDescription(String vnpTransactionStatus) {
    String result = "invalid status";
    switch (vnpTransactionStatus) {
      case "00":
        result = VnpTransactionStatus.SUCCESS.getMessage();
        break;
      case "01":
        result = VnpTransactionStatus.NOT_SUCCESS.getMessage();
        break;
      case "02":
        result = VnpTransactionStatus.ERROR.getMessage();
        break;
      case "04":
        result = VnpTransactionStatus.REVERSE.getMessage();
        break;
      case "05":
        result = VnpTransactionStatus.PROCESSING.getMessage();
        break;
      case "06":
        result = VnpTransactionStatus.REFUND.getMessage();
        break;
      case "07":
        result = VnpTransactionStatus.FRAUD.getMessage();
        break;
      case "09":
        result = VnpTransactionStatus.REJECT.getMessage();
        break;
    }
    return result;
  }

}
