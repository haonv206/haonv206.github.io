package vinnet.sim.helper;

import lombok.Data;

@Data
public class Constant {
    public final class ERROR_CODE {
        public static final String UPLOAD_FILE_SUCCESS = "UPLOAD_FILE_SUCCESS";
        public static final String CELL_TYPE_EXCEL_WAS_WRONG = "CELL_TYPE_EXCEL_WAS_WRONG"; //Kiểu dữ liệu sai định dạng
        public static final String LACK_OF_VARIABLE_IN_EXCEL = "LACK_OF_VARIABLE_IN_EXCEL";
        public static final String INVALID_NAME = "INVALID_NAME";
        public static final String INVALID_PHONE = "INVALID_PHONE";
        public static final String INVALID_EMAIL = "INVALID_EMAIL";
        public static final String INVALID_ADDRESS = "INVALID_ADDRESS";
        public static final String SUCCESS = "SUCCESS";
        public static final String SIM_NOT_FOUND = "SIM_NOT_FOUND";
        public static final String STATUS_INVALID = "STATUS_INVALID";
        public static final String ORDER_NULL = "ORDER_NULL";
        public static final String ORDER_NOT_FOUND = "ORDER_NOT_FOUND";
        public static final String EXCEL_NULL = "EXCEL_NULL";
        public static final String SESSION_NULL = "SESSION_NULL";
        public static final String NUMBER_NULL = "NUMBER_NULL";
        public static final String DISTRICT_NULL = "DISTRICT_NULL";
        public static final String PROVINCE_NULL = "PROVINCE_NULL";
        public static final String VILLAGE_NULL = "VILLAGE_NULL";
        public static final String PAYMENT_METHOD_NOT_FOUND = "PAYMENT_METHOD_NOT_FOUND";
        public static final String PHONE_IS_LOCKED = "PHONE_IS_LOCKED";
        public static final String ORDER_MAX_PHONE = "ORDER_MAX_PHONE";


        public static final String TRANSACTION_NOT_FOUND = "TRANSACTION_NOT_FOUND";
        public static final String NEW = "NEW";
    }
    public final class SIM_TYPE {
        public static final String TRA_TRUOC = "Trả trước";
        public static final String TRA_SAU = "Trả sau";
        public static final String INACTIVE = "INACTIVE";
        public static final String ACTIVE = "ACTIVE";
        public static final String LP = "LP"; //Lộc Phát
        public static final String NQG = "NQG"; //Sim ngũ quý giữa
        public static final String OD = "OD"; //Sim ông địa
        public static final String DB = "DB"; //Sim đào ba
        public static final String DH = "DH"; //Sim đào hai
        public static final String THG = "THG"; //Sim tam hoa gữa
        public static final String TT = "TT"; //Sim thần tài
        public static final String TL = "TL"; //Sim tiến liên
        public static final String TQG = "TQG"; //Sim tứ quý giữa
        public static final String TH = "TH"; //Tam hoa
    }


}
