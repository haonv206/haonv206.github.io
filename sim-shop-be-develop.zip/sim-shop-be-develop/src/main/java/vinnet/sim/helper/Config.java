package vinnet.sim.helper;

import lombok.Data;
import org.apache.commons.codec.digest.HmacUtils;
import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.util.Base64;

import static org.apache.commons.codec.digest.HmacAlgorithms.HMAC_SHA_512;

@Data
public class Config {


  public static String getIpAddress(HttpServletRequest req) {
    return req.getRemoteAddr();
  }

  public static String hmacSHA512(String hashSecret, String hashData) {
    return new HmacUtils(HMAC_SHA_512, hashSecret).hmacHex(hashData);
  }

  private static final String HMAC_SHA512 = "HmacSHA512";
  private static final String SECRET_KEY = "WHTRVPPDPYQSLGPRCOTMHGSVYLDAPKMI"; // Replace with your actual secret key

  public static String hashAllFields(Map<String, String> fields) {
    // Concatenate all field values
    StringBuilder concatenatedValues = new StringBuilder();
    fields.entrySet().stream()
            .sorted(Map.Entry.comparingByKey())
            .forEach(entry -> concatenatedValues.append(entry.getValue()));

    try {
      // Initialize HMAC-SHA-512 with your secret key
      Mac hmacSha512 = Mac.getInstance(HMAC_SHA512);
      SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes(StandardCharsets.UTF_8), HMAC_SHA512);
      hmacSha512.init(secretKey);

      // Compute the hash
      byte[] hashedBytes = hmacSha512.doFinal(concatenatedValues.toString().getBytes(StandardCharsets.UTF_8));

      // Encode the hash in Base64
      return Base64.getEncoder().encodeToString(hashedBytes);
    } catch (NoSuchAlgorithmException | InvalidKeyException e) {
      e.printStackTrace(); // Handle the exception according to your needs
      return null;
    }
  }

  public static String getRandomNumber(int length) {
    if (length <= 0) {
      throw new IllegalArgumentException("Length must be positive");
    }

    StringBuilder sb = new StringBuilder();
    SecureRandom random = new SecureRandom();

    // Generate random digits and append them to the string
    for (int i = 0; i < length; i++) {
      int digit = random.nextInt(10); // Generate a random digit between 0 (inclusive) and 9 (exclusive)
      sb.append(digit);
    }

    return sb.toString();
  }
}
