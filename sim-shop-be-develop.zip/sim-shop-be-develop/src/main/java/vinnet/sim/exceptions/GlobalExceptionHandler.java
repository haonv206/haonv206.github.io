package vinnet.sim.exceptions;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import vinnet.sim.domain.response.ExceptionResponse;


@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler({ResourceExitsException.class})
    public ResponseEntity<Object> handleFoundException(
            BaseException exception, WebRequest webRequest) {
        return new ResponseEntity<>(ExceptionResponse.createFrom(exception), HttpStatus.FOUND);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> handleNotFoundException(
            BaseException exception, WebRequest webRequest) {
        return new ResponseEntity<>(ExceptionResponse.createFrom(exception) , HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({BadRequestException.class, AccountNotExistsException.class})
    public ResponseEntity<Object> badRequestException(BaseException exception, WebRequest request) {
        return new ResponseEntity<>(ExceptionResponse.createFrom(exception), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> globalExceptionHandler(Exception exception, WebRequest request) {
        return new ResponseEntity<>(ExceptionResponse.createFrom(exception),  HttpStatus.INTERNAL_SERVER_ERROR);
    }





}
