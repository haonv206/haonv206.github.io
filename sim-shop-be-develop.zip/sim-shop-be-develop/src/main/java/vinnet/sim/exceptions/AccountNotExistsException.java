package vinnet.sim.exceptions;

public class AccountNotExistsException extends BaseException{
    private static final long serialVersionUID = 1L;

    public AccountNotExistsException(String message) {
        super(message);
    }
}
