package vinnet.sim.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vinnet.sim.domain.request.GetSimReq;

import javax.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin
@RequestMapping("/sims")
public class SimController extends BaseController{
  @PostMapping()
  public ResponseEntity<Object> getAll(@RequestBody GetSimReq req) {

    return ResponseEntity.ok(simService.getAll(req));
  }

  @PostMapping("/import")
  public ResponseEntity<Object> importSim(@ModelAttribute MultipartFile excelFile) {
    return ResponseEntity.ok(simService.importSim(excelFile));
  }

}
