package vinnet.sim.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;
import vinnet.sim.service.*;

@RestController
@Validated
public class BaseController {
    @Autowired
    SimService simService;
    @Autowired
    OrderService orderService;
    @Autowired
    CategoryService categoryService;

    @Autowired
    ConnectionVNPayService connectionVNPayService;

    @Autowired
    TransactionService transactionService;

}
