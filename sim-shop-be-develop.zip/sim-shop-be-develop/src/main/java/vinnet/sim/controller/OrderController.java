package vinnet.sim.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import vinnet.sim.domain.request.LockSimReq;
import vinnet.sim.domain.request.CreatCartReq;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@CrossOrigin
@RequestMapping("/orders")
public class OrderController extends BaseController {

  @PostMapping("/confirm")
  public Object paymentConfirm(@RequestBody CreatCartReq creatCartReq,
                                     HttpServletRequest req) throws Exception {

    return orderService.paymentConfirm(creatCartReq, req);
  }

  @PutMapping("/change_status")
  public ResponseEntity<Object> changeStatusSim(@RequestBody LockSimReq req, HttpSession httpSession) {
    return ResponseEntity.ok(orderService.changeStatusSim(req, httpSession));
  }


}
