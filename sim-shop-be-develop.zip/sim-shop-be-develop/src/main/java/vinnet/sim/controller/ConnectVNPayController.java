package vinnet.sim.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

@RestController
@RequestMapping
@CrossOrigin
public class ConnectVNPayController extends BaseController{

  @GetMapping("/ReturnUrl")
  public RedirectView returnFromVNPay(HttpServletRequest req) {
    RedirectView redirectView = new RedirectView();
    String url = connectionVNPayService.returnFromVNPay(req);
    redirectView.setUrl(url);
    return redirectView;
  }

  @GetMapping("/ipn")
  public ResponseEntity<Object> ipnFromVNPay(HttpServletRequest request){
    return ResponseEntity.ok(connectionVNPayService.ipnFromVNPay(request));
  }

}
