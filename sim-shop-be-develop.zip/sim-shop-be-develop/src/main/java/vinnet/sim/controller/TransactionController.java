package vinnet.sim.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vinnet.sim.domain.request.StatusTransactionReq;

@CrossOrigin
@RestController
@RequestMapping("/transactions")
public class TransactionController extends BaseController{

  @PostMapping("/status")
  public ResponseEntity<Object> checkTransactionStatus(@RequestBody StatusTransactionReq req){
    return ResponseEntity.ok(transactionService.checkStatusTransaction(req));
  }

}
