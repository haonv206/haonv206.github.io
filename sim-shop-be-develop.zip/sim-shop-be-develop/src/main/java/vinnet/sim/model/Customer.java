package vinnet.sim.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "phone")
    private String phone;

    @Column(name = "email")
    private String email;

    @Column(name = "province")
    private String province;

    @Column(name = "district")
    private String district;

    @Column(name = "village")
    private String village;

    @Column(name = "address")
    private String address;

    @Column(name = "note")
    private String note;
}
