package vinnet.sim.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Setter
@Getter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "transaction")
public class Transaction implements Serializable {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @OneToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "order_id", nullable = true)
  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  private Order order;

  @Column(name = "status")
  private String status;

  @Column(name = "vnp_TmnCode")
  private String vnpTmnCode;

  @Column(name = "vnp_Amount")
  private Double vnpAmount;

  @Column(name = "vnp_BankCode")
  private String vnpBankCode;

  @Column(name = "vnp_BankTranNo")
  private String vnpBankTranNo;

  @Column(name = "vnp_CardType")
  private String vnpCardType;

  @Column(name = "vnp_PayDate")
  private String vnpPayDate;

  @Column(name = "vnp_OrderInfo")
  private String vnpOrderInfo;

  @Column(name = "vnp_TransactionNo")
  private String vnpTransactionNo;

  @Column(name = "vnp_ResponseCode")
  private String vnpResponseCode;

  @Column(name = "vnp_TransactionStatus")
  private String vnpTransactionStatus;

  @Column(name = "description")
  private String description;

  @Column(name = "vnp_TxnRef")
  private String vnpTxnRef;

  @Column(name = "vnp_SecureHashType")
  private String vnpSecureHashType;

  @Column(name = "vnp_SecureHash")
  private String vnpSecureHash;

  @Column(name = "created_at")
  @CreationTimestamp
  private LocalDateTime createdAt;

  @Column(name = "updated_at")
  @UpdateTimestamp
  private LocalDateTime updatedAt;

}
