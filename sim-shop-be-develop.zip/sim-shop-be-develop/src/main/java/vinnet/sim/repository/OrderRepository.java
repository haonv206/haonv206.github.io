package vinnet.sim.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import vinnet.sim.model.Order;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Order findBySessionIdAndStatusNot(String sessionId, String status);

    Order findBySessionIdAndStatusIn(String sessionId, List<String> status);

    Order findBySessionIdAndStatus(String sessionId, String status);
    Order findByCode(String code);

    List<Order> findAllByStatusInAndExpireTimeBefore(List<String> status, LocalDateTime currentTime);
}
